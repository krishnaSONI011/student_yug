import TopSection from "./Components/Home/TopSection";


export default function Home() {
  return (
   <>
   <div>
    <TopSection />
   </div>
   
   </>
  );
}
