import SimpleLineChart from "../../Components/charts/Chart"


export default function EA(){
    return (
        <>
        <div>
            <div className="bg-white mx-10 my-5 p-5  ">
             <h1 className="text-2xl font-bold cursor-default">Enviromental Analysis</h1>
            <SimpleLineChart />
            </div>
          
        </div>
        
        </>
    )
}