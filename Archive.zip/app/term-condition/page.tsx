


export default function TermsAndService(){
    return(
        <>
          <div className="flex justify-center items-center h-[40vh] bg-gradient-to-br from-[#204b74] via-[#204b74] to-[#204b74] text-white ">
                    <h1 className="text-center text-5xl md:text-7xl font-bold mb-6 leading-tight">Terms of Service</h1>
          </div>


        <div className="px-2 py-2 mb-10">
            <p className="mt-10 text-lg text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet vero in eos voluptates, voluptatibus velit consequatur tenetur error, illum excepturi sint ut! Sint unde adipisci odit doloribus commodi assumenda facilis. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut ipsam eum enim quisquam accusantium eligendi a! Illum possimus nobis, sunt doloribus quidem sed ab molestiae est harum unde fuga vel.</p>
            <p className="mt-10 text-lg text-justify ">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet vero in eos voluptates, voluptatibus velit consequatur tenetur error, illum excepturi sint ut! Sint unde adipisci odit doloribus commodi assumenda facilis. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut ipsam eum enim quisquam accusantium eligendi a! Illum possimus nobis, sunt doloribus quidem sed ab molestiae est harum unde fuga vel.</p>
            <p className="mt-10 text-lg text-justify ">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet vero in eos voluptates, voluptatibus velit consequatur tenetur error, illum excepturi sint ut! Sint unde adipisci odit doloribus commodi assumenda facilis. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut ipsam eum enim quisquam accusantium eligendi a! Illum possimus nobis, sunt doloribus quidem sed ab molestiae est harum unde fuga vel.</p>
            

        </div>


          
        </>
    )
}